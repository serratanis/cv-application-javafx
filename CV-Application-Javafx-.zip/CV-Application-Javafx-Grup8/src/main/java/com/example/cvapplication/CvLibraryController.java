package com.example.cvapplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class CvLibraryController implements Initializable {

    @FXML private TreeView<String> folderTree;
    @FXML private VBox fileListContainer;
    @FXML private Label lblCurrentFolder;


    private final String BASE_PATH = System.getProperty("user.home") + File.separator + "Documents"
            + File.separator + "CV_Creator_Library" + File.separator + HelloController.getLoggedInUserEmail();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        checkBaseDirectory();
        refreshTree();
    }

    private void checkBaseDirectory() {
        File dir = new File(BASE_PATH);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    private void refreshTree() {
        TreeItem<String> root = new TreeItem<>("Kütüphanem");
        root.setExpanded(true);
        File baseDir = new File(BASE_PATH);

        if (baseDir.listFiles() != null) {
            for (File file : baseDir.listFiles()) {
                if (file.isDirectory()) {
                    root.getChildren().add(new TreeItem<>(file.getName()));
                }
            }
        }
        folderTree.setRoot(root);

        folderTree.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                // Kök dizin seçilirse boş gönderilen, değilse klasör adı gönderilen kısım
                String folderName = newVal.getValue().equals("Kütüphanem") ? "" : newVal.getValue();
                loadFiles(folderName);
            }
        });
    }

    private void loadFiles(String folderName) {
        fileListContainer.getChildren().clear();
        String displayFolder = (folderName == null || folderName.isEmpty()) ? "Genel" : folderName;
        lblCurrentFolder.setText("Klasör: " + displayFolder);

        File dir = new File(BASE_PATH + File.separator + displayFolder);
        File[] files = dir.listFiles((d, name) ->
                name.toLowerCase().endsWith(".png") || name.toLowerCase().endsWith(".pdf")
        );

        if (files != null) {
            for (File f : files) {
                HBox row = new HBox(15);
                row.getStyleClass().add("file-row");
                row.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
                row.setCursor(javafx.scene.Cursor.HAND);

                // Çift Tık Dosya Açma Özelliği
                row.setOnMouseClicked(event -> {
                    if (event.getClickCount() == 2) {
                        dosyayiAc(f);
                    }
                });

                Label fileNameLabel = new Label(f.getName());
                fileNameLabel.getStyleClass().add("file-label");

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);

                Button btnDelete = new Button("Sil");
                btnDelete.getStyleClass().add("delete-button");
                btnDelete.setOnAction(e -> {
                    e.consume(); // Satırın tıklama olayını engeller
                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, f.getName() + " silinsin mi?");
                    confirm.showAndWait().ifPresent(response -> {
                        if (response == ButtonType.OK) {
                            if (f.delete()) loadFiles(folderName);
                        }
                    });
                });

                row.getChildren().addAll(fileNameLabel, spacer, btnDelete);
                fileListContainer.getChildren().add(row);
            }
        }
    }
    // --- YENİ EKLENEN YARDIMCI METOT (DOSYAYI SİSTEMDE AÇAR) ---
    private void dosyayiAc(File file) {
        try {
            // Bilgisayarın varsayılan masaüstü desteğini kontrol et
            if (java.awt.Desktop.isDesktopSupported()) {
                java.awt.Desktop.getDesktop().open(file);
            } else {
                // Alternatif: İşletim sistemine göre manuel komut gönder
                String os = System.getProperty("os.name").toLowerCase();
                if (os.contains("mac")) {
                    Runtime.getRuntime().exec("open " + file.getAbsolutePath());
                } else if (os.contains("win")) {
                    Runtime.getRuntime().exec("explorer " + file.getAbsolutePath());
                } else {
                    Runtime.getRuntime().exec("xdg-open " + file.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Alert error = new Alert(Alert.AlertType.ERROR, "Dosya açılamadı! Lütfen varsayılan bir PDF/Resim okuyucu olduğundan emin olun.");
            error.show();
        }
    }

    @FXML
    void handleNewFolder(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog("Yeni Kategori");
        dialog.setTitle("Klasör Oluştur");
        dialog.setHeaderText("Yeni bir CV kategorisi oluşturun:");
        dialog.setContentText("Kategori Adı:");

        dialog.showAndWait().ifPresent(name -> {
            File newDir = new File(BASE_PATH + "/" + name);
            if (!newDir.exists()) {
                newDir.mkdirs();
                refreshTree();
            }
        });
    }

    //  Klasör Silme Fonksiyonu
    @FXML
    void handleDeleteFolder(ActionEvent event) {
        TreeItem<String> selectedItem = folderTree.getSelectionModel().getSelectedItem();
        if (selectedItem == null || selectedItem.getValue().equals("Kütüphanem")) {
            showError("Lütfen silinecek bir alt klasör seçin.");
            return;
        }

        File folderToDelete = new File(BASE_PATH + "/" + selectedItem.getValue());

        Alert alert = new Alert(Alert.AlertType.WARNING, "Klasör ve içindeki tüm dosyalar silinecek!", ButtonType.YES, ButtonType.NO);
        alert.setTitle("Klasör Sil");
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                deleteDirectory(folderToDelete);
                refreshTree();
                fileListContainer.getChildren().clear();
            }
        });
    }

    // Klasörü içindeki dosyalarla birlikte silmek için yardımcı metod
    private void deleteDirectory(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirectory(f);
                else f.delete();
            }
        }
        dir.delete();
    }

    // Hata Gösterme
    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.show();
    }

    // Form Ekranına Geri Dönüş
    @FXML
    void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_form.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.centerOnScreen();
        } catch (IOException e) { e.printStackTrace(); }
    }
}
