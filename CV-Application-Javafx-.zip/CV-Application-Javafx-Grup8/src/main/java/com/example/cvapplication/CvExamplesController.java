package com.example.cvapplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CvExamplesController {

    // Örnek CVler Sayfasından Seçtiğimiz Cv Türü Form Ekranına Seçim olarak Gönderiliyor
    @FXML
    void handleSelectFunctional(ActionEvent event) {
        CvFormController.setSecilenCvTuru("Fonksiyonel CV");
        handleBack(event);
    }

    @FXML
    void handleSelectChronological(ActionEvent event) {
        CvFormController.setSecilenCvTuru("Kronolojik CV");
        handleBack(event);
    }

    @FXML
    void handleSelectCombination(ActionEvent event) {
        CvFormController.setSecilenCvTuru("Kombinasyon CV");
        handleBack(event);
    }

    @FXML
    void handleSelectAcademic(ActionEvent event) {
        CvFormController.setSecilenCvTuru("Akademik CV");
        handleBack(event);
    }

    //Form Ekranına Geri Dönüş
    @FXML
    void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_form.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("CV Creator - Form");
            stage.centerOnScreen();
        } catch (Exception e) {
            System.err.println("Form sayfasına dönülemedi: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
