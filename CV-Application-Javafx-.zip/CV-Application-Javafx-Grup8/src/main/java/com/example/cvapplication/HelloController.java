package com.example.cvapplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class HelloController implements Initializable {

    @FXML private VBox loginBox, registerBox, welcomeBox, mainCard;
    @FXML private TextField loginEmail, regName, regEmail;
    @FXML private PasswordField loginPass, regPass;
    @FXML private Label lblWelcomeMessage, lblStatus;
    @FXML private Button btnTabLogin, btnTabRegister;


    private static String loggedInUserEmail;

    public static String getLoggedInUserEmail() {
        return loggedInUserEmail;
    }

    // Verilerin kaydedileceği dosya yolu
    private final String DATA_FILE = "users.properties";
    private Properties users = new Properties();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loadUsers(); // Program açıldığında kayıtlı kullanıcıları dosyadan okuma bölümü
    }

    // Dosya İşlemleri
    private void loadUsers() {
        try (InputStream input = new FileInputStream(DATA_FILE)) {
            users.load(input);
        } catch (IOException e) {
            System.out.println("Henüz kayıtlı kullanıcı yok veya dosya bulunamadı.");
        }
    }

    // Kullanıcı Kaydetme
    private void saveUser(String email, String name, String pass) {
        users.setProperty(email, name + ":" + pass);
        try (OutputStream output = new FileOutputStream(DATA_FILE)) {
            users.store(output, "Kullanıcı Veritabanı");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //  Doğrulama E- Posta Formatı
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        return email != null && pat.matcher(email).matches();
    }

    // Kayıt Olma İşlemi
    @FXML
    void handleRegister(ActionEvent event) {
        String name = regName.getText();
        String email = regEmail.getText();
        String pass = regPass.getText();

        if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            showStatus("Lütfen tüm alanları doldurun.", true);
            return;
        }

        if (!isValidEmail(email)) {
            showStatus("Geçersiz e-posta formatı!", true);
            return;
        }

        if (users.containsKey(email)) {
            showStatus("Bu e-posta zaten kayıtlı!", true);
            return;
        }

        // Veriyi dosyaya kaydet
        saveUser(email, name, pass);
        showStatus("Kayıt başarılı! Giriş yapabilirsiniz.", false);
        showLogin(null);
    }

    // Giriş Yapma İşlemi
    @FXML
    void handleLogin(ActionEvent event) {
        String email = loginEmail.getText();
        String pass = loginPass.getText();

        if (users.containsKey(email)) {
            String userData = users.getProperty(email);
            String[] parts = userData.split(":"); // name:pass şeklinde ayır
            String storedName = parts[0];
            String storedPass = parts[1];

            if (pass.equals(storedPass)) {
                // Kullanıcı Bilgisini Saklıyoruz
                loggedInUserEmail = email;

                // Giriş Başarılı
                mainCard.setVisible(false);
                mainCard.setManaged(false);
                welcomeBox.setVisible(true);
                welcomeBox.setManaged(true);

                // Kayıt sırasındaki ismi değişkene ata
                lblWelcomeMessage.setText("Hoş Geldin, " + storedName + "!");
                // CV Formuna geçişte ismi kullanabilmek için saklıyoruz (regName görünmez bir depo gibi kullanılır)
                regName.setText(storedName);
            } else {
                showStatus("Hatalı şifre!", true);
            }
        } else {
            showStatus("Kullanıcı bulunamadı!", true);
        }
    }

    private void showStatus(String message, boolean isError) {
        lblStatus.setText(message);
        lblStatus.setStyle(isError ? "-fx-text-fill: #ff6b6b;" : "-fx-text-fill: #E2F1AF;");
    }

    // Ekran Geçişleri
    @FXML
    void showRegister(ActionEvent event) {
        loginBox.setVisible(false); loginBox.setManaged(false);
        registerBox.setVisible(true); registerBox.setManaged(true);
        btnTabRegister.getStyleClass().setAll("tab-button", "tab-button-active");
        btnTabLogin.getStyleClass().setAll("tab-button", "tab-button-inactive");
        lblStatus.setText("");
    }

    @FXML
    void showLogin(ActionEvent event) {
        registerBox.setVisible(false); registerBox.setManaged(false);
        loginBox.setVisible(true); loginBox.setManaged(true);
        btnTabLogin.getStyleClass().setAll("tab-button", "tab-button-active");
        btnTabRegister.getStyleClass().setAll("tab-button", "tab-button-inactive");
    }

    @FXML
    void openCvForm(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_form.fxml"));
            Parent root = loader.load();
            CvFormController cvFormController = loader.getController();
            cvFormController.setUserInfo(regName.getText()); // Dosyadan okunan isim gider
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.centerOnScreen();
        } catch (Exception e) { e.printStackTrace(); }
    }
}
