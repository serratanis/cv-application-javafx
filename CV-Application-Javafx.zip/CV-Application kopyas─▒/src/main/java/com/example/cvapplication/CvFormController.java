package com.example.cvapplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class CvFormController implements Initializable {

    private static boolean temizleEmri = false;
    public static void setTemizleEmri(boolean durum) { temizleEmri = durum; }
    // --- STATİK DEĞİŞKENLER ---
    private static String sKullaniciAdi;
    private static String sIsim, sSoyisim, sEmail, sTelefon, sLinkedin, sGithub, sProfil, sYetenek, sDeneyim, sProje, sEgitim, sSertifika, sDil, sReferans, sCvTuru;

    // Şablon galerisinden gelen seçimi takip etmek için
    private static String secilenTuruIsaretle = "Fonksiyonel CV";

    @FXML private Label lblWelcomeHeader;
    @FXML private VBox menuKisisel, menuProfil, menuDiger;
    @FXML private VBox formKisisel, formProfil, formDiger;
    @FXML private ComboBox<String> comboDil;
    @FXML private ToggleGroup tgCvTuru;

    @FXML private TextField tfIsim, tfSoyisim, tfEmail, tfTelefon, tfLinkedin, tfGithub;
    @FXML private TextField tfProfil, tfDeneyim, tfProje, tfYetenek;
    @FXML private TextField tfEgitim, tfSertifika, tfDil, tfReferans;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // --- YENİ EKLENEN TEMİZLİK KONTROLÜ ---
        if (temizleEmri) {
            formuVeStatikleriSifirla();
            temizleEmri = false;
        }

        // Dil ComboBox Ayarı - Almanca ve Fransızca Eklendi
        if (comboDil != null) {
            // Sadece buraya yeni dilleri ekliyoruz:
            comboDil.getItems().setAll("Türkçe", "İngilizce", "Almanca", "Fransızca");

            if (comboDil.getSelectionModel().isEmpty()) {
                comboDil.getSelectionModel().selectFirst();
            }
        }

        // Başlangıçta form bölümlerini kapalı tut
        closeSection(menuKisisel, formKisisel);
        closeSection(menuProfil, formProfil);
        closeSection(menuDiger, formDiger);

        // Kullanıcı ismi karşılama mesajı
        if (sKullaniciAdi != null && lblWelcomeHeader != null) {
            lblWelcomeHeader.setText("Hoş geldin, " + sKullaniciAdi + "!");
        }

        // Şablon Galerisinden Gelen Seçimi RadioButton'a Yansıt
        if (tgCvTuru != null) {
            tgCvTuru.getToggles().forEach(toggle -> {
                RadioButton rb = (RadioButton) toggle;
                if (rb.getText().equals(secilenTuruIsaretle)) {
                    rb.setSelected(true);
                    sCvTuru = secilenTuruIsaretle;
                }
            });
        }

        // Eğer temizlik emri gelmediyse ve veri varsa kutuları doldur
        if (sIsim != null) {
            tfIsim.setText(sIsim); tfSoyisim.setText(sSoyisim); tfEmail.setText(sEmail);
            tfTelefon.setText(sTelefon); tfLinkedin.setText(sLinkedin); tfGithub.setText(sGithub);
            tfProfil.setText(sProfil); tfYetenek.setText(sYetenek); tfDeneyim.setText(sDeneyim);
            tfProje.setText(sProje); tfEgitim.setText(sEgitim); tfSertifika.setText(sSertifika);
            tfDil.setText(sDil); tfReferans.setText(sReferans);
        }
    }

    // Tüm verileri (hem kutuları hem static değişkenleri) temizleyen yeni metot
    private void formuVeStatikleriSifirla() {
        // 1. Static değişkenleri null yap (Kutulara tekrar dolmasınlar)
        sIsim = null; sSoyisim = null; sEmail = null; sTelefon = null;
        sLinkedin = null; sGithub = null; sProfil = null; sYetenek = null;
        sDeneyim = null; sProje = null; sEgitim = null; sSertifika = null;
        sDil = null; sReferans = null;

        // 2. Kutuları temizle
        if (tfIsim != null) {
            tfIsim.clear(); tfSoyisim.clear(); tfEmail.clear();
            tfTelefon.clear(); tfLinkedin.clear(); tfGithub.clear();
            tfProfil.clear(); tfYetenek.clear(); tfDeneyim.clear();
            tfProje.clear(); tfEgitim.clear(); tfSertifika.clear();
            tfDil.clear(); tfReferans.clear();
        }
    }

    // --- DIŞARIDAN VERİ SET ETME METOTLARI (STATİK) ---

    public void setUserInfo(String adSoyad) {
        sKullaniciAdi = adSoyad;
        if (lblWelcomeHeader != null) lblWelcomeHeader.setText("Hoş geldin, " + adSoyad + "!");
    }

    public static void setSecilenCvTuru(String tur) {
        secilenTuruIsaretle = tur;
        sCvTuru = tur;
    }

    public static String getSecilenCvTuru() { return sCvTuru; }

    // --- YARDIMCI METOTLAR ---

    private void verileriBellegeAl() {
        sIsim = tfIsim.getText(); sSoyisim = tfSoyisim.getText(); sEmail = tfEmail.getText();
        sTelefon = tfTelefon.getText(); sLinkedin = tfLinkedin.getText(); sGithub = tfGithub.getText();
        sProfil = tfProfil.getText(); sYetenek = tfYetenek.getText(); sDeneyim = tfDeneyim.getText();
        sProje = tfProje.getText(); sEgitim = tfEgitim.getText(); sSertifika = tfSertifika.getText();
        sDil = tfDil.getText(); sReferans = tfReferans.getText();

        if (tgCvTuru != null && tgCvTuru.getSelectedToggle() != null) {
            RadioButton selected = (RadioButton) tgCvTuru.getSelectedToggle();
            sCvTuru = selected.getText();
            secilenTuruIsaretle = sCvTuru; // Seçimi güncelle
        }
    }

    // --- NAVİGASYON VE BUTON İŞLEMLERİ ---

    @FXML
    void handleOnizleme(ActionEvent event) {
        try {
            verileriBellegeAl();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_preview.fxml"));
            Parent root = loader.load();
            CvPreviewController previewController = loader.getController();
            previewController.setCvData(sIsim, sSoyisim, sEmail, sTelefon, sLinkedin, sGithub, sProfil, sYetenek, sDeneyim, sProje, sEgitim, sSertifika, sDil, sReferans, comboDil.getValue());
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("CV Önizleme - " + sCvTuru);
        } catch (Exception e) { e.printStackTrace(); }
    }

    @FXML
    void handleKaydet(ActionEvent event) {
        try {
            verileriBellegeAl();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_download.fxml"));
            Parent root = loader.load();
            CvDownloadController downloadController = loader.getController();
            downloadController.setCvData(sIsim, sSoyisim, sEmail, sTelefon, sLinkedin, sGithub, sProfil, sYetenek, sDeneyim, sProje, sEgitim, sSertifika, sDil, sReferans, comboDil.getValue());
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("CV Kaydet ve İndir (" + sCvTuru + ")");
        } catch (Exception e) { e.printStackTrace(); }
    }

    @FXML
    void handleCvOrnekleri(ActionEvent event) {
        try {
            verileriBellegeAl(); // Formda yazılanları kaybetmemek için belleğe al
            System.out.println("CV Örnekleri galerisi açılıyor...");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_examples.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("CV Şablonları ve Rehber");
            stage.centerOnScreen();
        } catch (Exception e) {
            System.err.println("Hata: cv_examples.fxml yüklenemedi!");
            e.printStackTrace();
        }
    }

    @FXML
    void handleCvKitapligim(ActionEvent event) {
        try {
            verileriBellegeAl();
            System.out.println("Kullanıcının kayıtlı CV'leri listeleniyor...");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_library.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("CV Kitaplığım");
            stage.centerOnScreen();
        } catch (Exception e) {
            System.err.println("Hata: cv_library.fxml yüklenemedi!");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleCikisYap(ActionEvent event) {
        try {
            // HAFIZAYI SIFIRLA
            sKullaniciAdi = null; sIsim = null; sSoyisim = null; sEmail = null;
            sTelefon = null; sLinkedin = null; sGithub = null; sProfil = null;

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/home-view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.centerOnScreen();
            stage.setTitle("Giriş Yap / Kayıt Ol");
            stage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // --- FORM GÖRÜNÜM KONTROLLERİ ---

    @FXML void toggleKisisel(ActionEvent event) { toggleBoth(menuKisisel, formKisisel); }
    @FXML void toggleProfil(ActionEvent event) { toggleBoth(menuProfil, formProfil); }
    @FXML void toggleDiger(ActionEvent event) { toggleBoth(menuDiger, formDiger); }

    private void toggleBoth(VBox menu, VBox form) {
        boolean isNowVisible = !menu.isVisible();
        menu.setVisible(isNowVisible);
        menu.setManaged(isNowVisible);
        form.setVisible(isNowVisible);
        form.setManaged(isNowVisible);
    }

    private void closeSection(VBox menu, VBox form) {
        if (menu != null && form != null) {
            menu.setVisible(false); menu.setManaged(false);
            form.setVisible(false); form.setManaged(false);
        }
    }
}

