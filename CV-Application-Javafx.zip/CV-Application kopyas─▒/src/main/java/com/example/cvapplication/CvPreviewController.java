package com.example.cvapplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class CvPreviewController {

    @FXML private VBox cvKagit;
    @FXML private Label lblAdSoyad, lblTelefonVeri, lblEmailVeri, lblLinkedinVeri, lblGithubVeri;
    @FXML private Label lblOzetVeri, lblDeneyimVeri, lblProjeVeri, lblYetenekVeri, lblEgitimVeri, lblSertifikaVeri, lblDilVeri, lblReferansVeri;

    public void setCvData(String ad, String soyad, String email, String tel, String ln, String gh,
                          String ozet, String yetenek, String deneyim, String proje,
                          String egitim, String sertifika, String dil, String referans, String dilSecimi) {

        String hedefKod = "tr";
        if ("İngilizce".equals(dilSecimi)) hedefKod = "en";
        else if ("Almanca".equals(dilSecimi)) hedefKod = "de";
        else if ("Fransızca".equals(dilSecimi)) hedefKod = "fr";

        boolean cevirmeGerekli = !hedefKod.equals("tr");

        if (cevirmeGerekli) {
            ozet = googleTranslate(ozet, hedefKod);
            deneyim = googleTranslate(deneyim, hedefKod);
            proje = googleTranslate(proje, hedefKod);
            yetenek = googleTranslate(yetenek, hedefKod);
            egitim = googleTranslate(egitim, hedefKod);
            sertifika = googleTranslate(sertifika, hedefKod);
            dil = googleTranslate(dil, hedefKod);
            referans = googleTranslate(referans, hedefKod);
        }

        lblAdSoyad.setText(ad.toUpperCase() + " " + soyad.toUpperCase());

        String phoneHeader = "Telefon: ";
        String emailHeader = "E-posta: ";

        if ("en".equals(hedefKod)) {
            phoneHeader = "Phone: ";
            emailHeader = "Email: ";
        } else if ("de".equals(hedefKod)) {
            phoneHeader = "Telefon: ";
            emailHeader = "E-Mail: ";
        } else if ("fr".equals(hedefKod)) {
            phoneHeader = "Téléphone: ";
            emailHeader = "E-mail: ";
        }

        lblTelefonVeri.setText(phoneHeader + tel);
        lblEmailVeri.setText(emailHeader + email);
        lblLinkedinVeri.setText("LinkedIn: " + ln);
        lblGithubVeri.setText("GitHub: " + gh);

        setupLabel(lblOzetVeri, ozet);
        setupLabel(lblDeneyimVeri, deneyim);
        setupLabel(lblProjeVeri, proje);
        setupLabel(lblYetenekVeri, yetenek);
        setupLabel(lblEgitimVeri, egitim);
        setupLabel(lblSertifikaVeri, sertifika);
        setupLabel(lblDilVeri, dil);
        setupLabel(lblReferansVeri, referans);

        diliVeTasarimiUygula(dilSecimi);
        duzenleCvYapisi(CvFormController.getSecilenCvTuru());

        cvKagit.setPrefHeight(Region.USE_COMPUTED_SIZE);
        cvKagit.setMinHeight(Region.USE_PREF_SIZE);
    }

    private void setupLabel(Label lbl, String text) {
        lbl.setText(text);
        lbl.setWrapText(true);
        lbl.setMaxWidth(520);
        lbl.setMinHeight(Region.USE_PREF_SIZE);
        lbl.setPrefHeight(Region.USE_COMPUTED_SIZE);

        if (text != null && text.length() > 600) {
            lbl.setStyle("-fx-font-size: 11px; -fx-text-fill: #444444; -fx-font-weight: normal;");
        } else {
            lbl.setStyle("-fx-font-size: 12px; -fx-text-fill: #444444; -fx-font-weight: normal;");
        }
    }

    private String googleTranslate(String metin, String hedefDilKodu) {
        if (metin == null || metin.trim().isEmpty()) return "";
        try {
            String urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=tr&tl="
                    + hedefDilKodu + "&dt=t&q="
                    + URLEncoder.encode(metin, StandardCharsets.UTF_8);
            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("User-Agent", "Mozilla/5.0");
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) response.append(inputLine);
            in.close();
            String raw = response.toString();
            return raw.substring(raw.indexOf("\"") + 1, raw.indexOf("\"", raw.indexOf("\"") + 1));
        } catch (Exception e) {
            return metin;
        }
    }

    private void diliVeTasarimiUygula(String dil) {
        cvKagit.setSpacing(8);
        cvKagit.setPadding(new Insets(30, 40, 30, 40));

        cvKagit.getChildren().removeIf(node -> node instanceof Line);

        lblAdSoyad.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #1a1a1a;");

        for (Node node : cvKagit.getChildren()) {
            if (node instanceof Label) {
                applyLogic((Label) node, dil);
            } else if (node instanceof HBox) {
                for (Node subNode : ((HBox) node).getChildren()) {
                    if (subNode instanceof Label) applyLogic((Label) subNode, dil);
                }
            }
        }

        ekleYatayCizgi(6);
        ekleYatayCizgi(17);
    }

    private void applyLogic(Label lbl, String secilenDil) {

        if (lbl.getId() != null && lbl.getId().startsWith("lbl") && lbl.getId().endsWith("Veri")
                && !lbl.getId().equals("lblAdSoyad")) {
            return;
        }

        String txt = lbl.getText();
        if (txt == null || txt.trim().isEmpty()) return;

        String check = txt.toLowerCase(Locale.forLanguageTag("tr-TR")).trim();

        // 🔴 SADECE BURASI GENİŞLETİLDİ
        if (check.contains("iletisim") || check.contains("iletişim") || check.contains("i̇letişim")
                || check.contains("contact") || check.contains("kontakt")) {

            if (secilenDil.equals("İngilizce")) lbl.setText("Contact");
            else if (secilenDil.equals("Almanca")) lbl.setText("Kontakt");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Contact");
            else lbl.setText("İletişim");
            stilUygula(lbl);

            // 🔴 SADECE BURASI GENİŞLETİLDİ
        } else if (check.contains("egitim") || check.contains("eğitim")
                || check.contains("education") || check.contains("ausbildung") || check.contains("bildung")) {

            if (secilenDil.equals("İngilizce")) lbl.setText("Education:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Ausbildung:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Éducation:");
            else lbl.setText("Eğitimler:");
            stilUygula(lbl);

        } else if (check.contains("profil") || check.contains("summary") || check.contains("zusammenfassung")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("Professional Summary:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Zusammenfassung:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Résumé Professionnel:");
            else lbl.setText("Profil Özeti:");
            stilUygula(lbl);
        }
        // ⬇️ BURADAN SONRASI KODUNUN AYNISI
        else if (check.contains("deneyim") || check.contains("experience") || check.contains("erfahrung")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("Experience:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Berufserfahrung:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Expérience:");
            else lbl.setText("Deneyimler:");
            stilUygula(lbl);
        } else if (check.contains("proje") || check.contains("projects")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("Projects:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Projekte:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Projets:");
            else lbl.setText("Projeler:");
            stilUygula(lbl);
        } else if (check.contains("yetenek") || check.contains("skills") || check.contains("kenntnisse")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("Skills:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Kenntnisse:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Compétences:");
            else lbl.setText("Yetenekler:");
            stilUygula(lbl);
        } else if (check.contains("sertifika") || check.contains("certificates")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("Certificates:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Zertifikate:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Certificats:");
            else lbl.setText("Sertifikalar:");
            stilUygula(lbl);
        } else if (check.contains("dil") || check.contains("languages") || check.contains("sprachen")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("Languages:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Sprachen:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Langues:");
            else lbl.setText("Bilinen Diller:");
            stilUygula(lbl);
        } else if (check.contains("referans") || check.contains("references")) {
            if (secilenDil.equals("İngilizce")) lbl.setText("References:");
            else if (secilenDil.equals("Almanca")) lbl.setText("Referenzen:");
            else if (secilenDil.equals("Fransızca")) lbl.setText("Références:");
            else lbl.setText("Referanslar:");
            stilUygula(lbl);
        }
    }

    private void stilUygula(Label lbl) {
        lbl.setStyle("-fx-font-weight: bold; -fx-font-size: 15px; -fx-text-fill: #2c3e50;");
        lbl.setPadding(new Insets(12, 0, 0, 0));
        lbl.setMinHeight(Region.USE_PREF_SIZE);
    }

    private void ekleYatayCizgi(int index) {
        Line line = new Line(0, 0, 515, 0);
        line.setStroke(Color.web("#eeeeee"));
        line.setStrokeWidth(1.2);
        if (index <= cvKagit.getChildren().size()) {
            cvKagit.getChildren().add(index, line);
        }
    }

    private void duzenleCvYapisi(String tur) {
        if (tur == null || tur.isEmpty()) return;
        switch (tur) {
            case "Kronolojik CV": tasimaYap(lblDeneyimVeri, 11); break;
            case "Akademik CV":
                tasimaYap(lblEgitimVeri, 11);
                tasimaYap(lblSertifikaVeri, 13);
                break;
            case "Kombinasyon CV":
                tasimaYap(lblYetenekVeri, 11);
                tasimaYap(lblDeneyimVeri, 13);
                break;
        }
    }

    private void tasimaYap(Node node, int index) {
        if (cvKagit.getChildren().contains(node)) {
            cvKagit.getChildren().remove(node);
            int safeIndex = Math.min(index, cvKagit.getChildren().size());
            cvKagit.getChildren().add(safeIndex, node);
        }
    }

    @FXML
    void handleGeriDon(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cvapplication/cv_form.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("CV Oluşturma Formu");
            stage.centerOnScreen();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}