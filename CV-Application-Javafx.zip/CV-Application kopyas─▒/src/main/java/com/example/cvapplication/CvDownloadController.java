package com.example.cvapplication;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class CvDownloadController {

    @FXML private VBox cvKagit;
    @FXML private Label lblAdSoyad, lblTelefonVeri, lblEmailVeri, lblLinkedinVeri, lblGithubVeri;
    @FXML private Label lblOzetVeri, lblDeneyimVeri, lblProjeVeri, lblYetenekVeri, lblEgitimVeri, lblSertifikaVeri, lblDilVeri, lblReferansVeri;

    public void setCvData(String ad, String soyad, String email, String tel, String ln, String gh,
                          String ozet, String yetenek, String deneyim, String proje,
                          String egitim, String sertifika, String dil, String referans, String dilSecimi) {

        String hedefKod = "tr";
        if ("İngilizce".equals(dilSecimi)) hedefKod = "en";
        else if ("Almanca".equals(dilSecimi)) hedefKod = "de";
        else if ("Fransızca".equals(dilSecimi)) hedefKod = "fr";

        if (!hedefKod.equals("tr")) {
            ozet = googleTranslate(ozet, hedefKod);
            deneyim = googleTranslate(deneyim, hedefKod);
            proje = googleTranslate(proje, hedefKod);
            yetenek = googleTranslate(yetenek, hedefKod);
            egitim = googleTranslate(egitim, hedefKod);
            sertifika = googleTranslate(sertifika, hedefKod);
            dil = googleTranslate(dil, hedefKod);
            referans = googleTranslate(referans, hedefKod);
        }

        lblAdSoyad.setText(ad.toUpperCase() + " " + soyad.toUpperCase());

        String phoneLabel = "Telefon: ";
        String emailLabel = "E-posta: ";

        if (hedefKod.equals("en")) { phoneLabel = "Phone: "; emailLabel = "Email: "; }
        else if (hedefKod.equals("de")) { phoneLabel = "Telefon: "; emailLabel = "E-Mail: "; }
        else if (hedefKod.equals("fr")) { phoneLabel = "Téléphone: "; emailLabel = "E-mail: "; }

        lblTelefonVeri.setText(phoneLabel + tel);
        lblEmailVeri.setText(emailLabel + email);
        lblLinkedinVeri.setText("LinkedIn: " + ln);
        lblGithubVeri.setText("GitHub: " + gh);

        setupLabel(lblOzetVeri, ozet);
        setupLabel(lblDeneyimVeri, deneyim);
        setupLabel(lblProjeVeri, proje);
        setupLabel(lblYetenekVeri, yetenek);
        setupLabel(lblEgitimVeri, egitim);
        setupLabel(lblSertifikaVeri, sertifika);
        setupLabel(lblDilVeri, dil);
        setupLabel(lblReferansVeri, referans);

        diliVeTasarimiUygula(dilSecimi);
        duzenleCvYapisi(CvFormController.getSecilenCvTuru());

        cvKagit.setPrefHeight(Region.USE_COMPUTED_SIZE);
        cvKagit.setMinHeight(Region.USE_PREF_SIZE);
    }

    private void setupLabel(Label lbl, String text) {
        lbl.setText(text);
        lbl.setWrapText(true);
        lbl.setMaxWidth(520);
        lbl.setMinHeight(Region.USE_PREF_SIZE);
        lbl.setPrefHeight(Region.USE_COMPUTED_SIZE);
        lbl.setStyle("-fx-font-size: 12px; -fx-text-fill: #444444; -fx-font-weight: normal;");
    }

    private String googleTranslate(String metin, String hedefDilKodu) {
        if (metin == null || metin.trim().isEmpty()) return "";
        try {
            String urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=tr&tl="
                    + hedefDilKodu + "&dt=t&q=" + URLEncoder.encode(metin, StandardCharsets.UTF_8);
            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("User-Agent", "Mozilla/5.0");
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) response.append(inputLine);
            in.close();
            String raw = response.toString();
            return raw.substring(raw.indexOf("\"") + 1, raw.indexOf("\"", raw.indexOf("\"") + 1));
        } catch (Exception e) {
            return metin;
        }
    }

    private void diliVeTasarimiUygula(String dilSecimi) {
        cvKagit.setSpacing(8);
        cvKagit.setPadding(new Insets(30, 40, 30, 40));
        cvKagit.getChildren().removeIf(node -> node instanceof Line);

        for (Node node : cvKagit.getChildren()) {
            if (node instanceof Label) {
                Label lbl = (Label) node;
                if (lbl.getId() == null || lbl.getId().isEmpty()) applyLogic(lbl, dilSecimi);
            } else if (node instanceof HBox) {
                for (Node subNode : ((HBox) node).getChildren()) {
                    if (subNode instanceof Label) {
                        Label subLbl = (Label) subNode;
                        if (subLbl.getId() == null || subLbl.getId().isEmpty()) applyLogic(subLbl, dilSecimi);
                    }
                }
            }
        }
        ekleYatayCizgi(6);
        ekleYatayCizgi(17);
    }

    private void applyLogic(Label lbl, String secilenDil) {
        String txt = lbl.getText();
        if (txt == null || txt.trim().isEmpty()) return;

        String check = txt.toLowerCase(Locale.forLanguageTag("tr-TR"));

        if (check.contains("iletisim") || check.contains("iletişim") || check.contains("contact") || check.contains("kontakt")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Contact"); break;
                case "Almanca": lbl.setText("Kontakt"); break;
                case "Fransızca": lbl.setText("Contact"); break;
                default: lbl.setText("İletişim");
            }
        } else if (check.contains("profil") || check.contains("summary") || check.contains("zusammenfassung")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Professional Summary:"); break;
                case "Almanca": lbl.setText("Zusammenfassung:"); break;
                case "Fransızca": lbl.setText("Résumé Professionnel:"); break;
                default: lbl.setText("Profil Özeti:");
            }
        } else if (check.contains("deneyim") || check.contains("experience") || check.contains("erfahrung")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Experience:"); break;
                case "Almanca": lbl.setText("Berufserfahrung:"); break;
                case "Fransızca": lbl.setText("Expérience:"); break;
                default: lbl.setText("Deneyimler:");
            }
        } else if (check.contains("egitim") || check.contains("eğitim") || check.contains("education") || check.contains("bildung") || check.contains("ausbildung")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Education:"); break;
                case "Almanca": lbl.setText("Ausbildung:"); break;
                case "Fransızca": lbl.setText("Éducation:"); break;
                default: lbl.setText("Eğitimler:");
            }
        } else if (check.contains("yetenek") || check.contains("skills") || check.contains("kenntnisse")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Skills:"); break;
                case "Almanca": lbl.setText("Kenntnisse:"); break;
                case "Fransızca": lbl.setText("Compétences:"); break;
                default: lbl.setText("Yetenekler:");
            }
        } else if (check.contains("proje") || check.contains("projects")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Projects:"); break;
                case "Almanca": lbl.setText("Projekte:"); break;
                case "Fransızca": lbl.setText("Projets:"); break;
                default: lbl.setText("Projeler:");
            }
        } else if (check.contains("sertifika") || check.contains("certificates")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Certificates:"); break;
                case "Almanca": lbl.setText("Zertifikate:"); break;
                case "Fransızca": lbl.setText("Certificats:"); break;
                default: lbl.setText("Sertifikalar:");
            }
        } else if (check.contains("dil") || check.contains("languages") || check.contains("sprachen")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("Languages:"); break;
                case "Almanca": lbl.setText("Sprachen:"); break;
                case "Fransızca": lbl.setText("Langues:"); break;
                default: lbl.setText("Bilinen Diller:");
            }
        } else if (check.contains("referans") || check.contains("references")) {
            switch (secilenDil) {
                case "İngilizce": lbl.setText("References:"); break;
                case "Almanca": lbl.setText("Referenzen:"); break;
                case "Fransızca": lbl.setText("Références:"); break;
                default: lbl.setText("Referanslar:");
            }
        }

        stilUygula(lbl);
    }

    private void stilUygula(Label lbl) {
        lbl.setStyle("-fx-font-weight: bold; -fx-font-size: 15px; -fx-text-fill: #2c3e50;");
        lbl.setPadding(new Insets(12, 0, 0, 0));
        lbl.setMinHeight(Region.USE_PREF_SIZE);
    }

    private void ekleYatayCizgi(int index) {
        Line line = new Line(0, 0, 515, 0);
        line.setStroke(Color.web("#eeeeee"));
        line.setStrokeWidth(1.2);
        if (index <= cvKagit.getChildren().size()) cvKagit.getChildren().add(index, line);
    }

    private void duzenleCvYapisi(String tur) {
        if (tur == null || tur.isEmpty()) return;
        switch (tur) {
            case "Kronolojik CV": tasimaYap(lblDeneyimVeri, 11); break;
            case "Akademik CV":
                tasimaYap(lblEgitimVeri, 11);
                tasimaYap(lblSertifikaVeri, 13);
                break;
            case "Kombinasyon CV":
                tasimaYap(lblYetenekVeri, 11);
                tasimaYap(lblDeneyimVeri, 13);
                break;
        }
    }

    private void tasimaYap(Node node, int index) {
        if (cvKagit.getChildren().contains(node)) {
            cvKagit.getChildren().remove(node);
            int safeIndex = Math.min(index, cvKagit.getChildren().size());
            cvKagit.getChildren().add(safeIndex, node);
        }
    }

    @FXML
    void handlePdfIndir(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("CV'yi Kaydet");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Resim Dosyası", "*.png"));
        String dosyaAdi = lblAdSoyad.getText().replace(" ", "_") + "_CV.png";
        fileChooser.setInitialFileName(dosyaAdi);

        File selectedFile = fileChooser.showSaveDialog(cvKagit.getScene().getWindow());
        if (selectedFile != null) {
            try {
                SnapshotParameters params = new SnapshotParameters();
                params.setFill(Color.WHITE);
                WritableImage snapshot = cvKagit.snapshot(params, null);
                ImageIO.write(SwingFXUtils.fromFXImage(snapshot, null), "png", selectedFile);

                String userEmail = HelloController.getLoggedInUserEmail();
                if (userEmail == null || userEmail.isEmpty()) userEmail = "misafir";

                String userLibraryBase = System.getProperty("user.home") + File.separator + "Documents"
                        + File.separator + "CV_Creator_Library" + File.separator + userEmail;

                File userDir = new File(userLibraryBase);
                if (!userDir.exists()) userDir.mkdirs();

                java.util.List<String> klasorler = new java.util.ArrayList<>();
                klasorler.add("Genel");
                File[] altKlasorler = userDir.listFiles(File::isDirectory);
                if (altKlasorler != null) {
                    for (File f : altKlasorler)
                        if (!f.getName().equals("Genel")) klasorler.add(f.getName());
                }

                javafx.scene.control.ChoiceDialog<String> dialog =
                        new javafx.scene.control.ChoiceDialog<>("Genel", klasorler);

                dialog.setTitle("Kitaplık Klasör Seçimi");
                dialog.setHeaderText("CV kitaplığınızda hangi klasöre eklensin?");
                dialog.showAndWait().ifPresent(secilenKlasor -> {
                    try {
                        String finalLibraryPath = userLibraryBase + File.separator + secilenKlasor;
                        new File(finalLibraryPath).mkdirs();
                        ImageIO.write(
                                SwingFXUtils.fromFXImage(snapshot, null),
                                "png",
                                new File(finalLibraryPath + File.separator + dosyaAdi)
                        );
                    } catch (Exception e) { e.printStackTrace(); }
                });

                CvFormController.setTemizleEmri(true);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Başarılı");
                alert.setContentText("CV başarıyla kaydedildi!");
                alert.showAndWait();

            } catch (Exception e) { e.printStackTrace(); }
        }
    }

    @FXML
    void handleGeriDon(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/cvapplication/cv_form.fxml"));
            ((Stage) ((Node) event.getSource()).getScene().getWindow()).setScene(new Scene(root));
        } catch (Exception e) { e.printStackTrace(); }
    }
}