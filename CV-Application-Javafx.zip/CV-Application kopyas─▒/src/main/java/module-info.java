module com.example.cvapplication {
    requires javafx.controls;
    requires javafx.fxml;
    // Hatanın çözümü için aşağıdaki satırı ekledik:
    requires javafx.swing;

    opens com.example.cvapplication to javafx.fxml;
    exports com.example.cvapplication;
}